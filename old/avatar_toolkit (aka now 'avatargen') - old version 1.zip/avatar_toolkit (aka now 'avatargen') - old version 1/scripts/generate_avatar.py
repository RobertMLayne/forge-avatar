# Standalone script entrypoint
